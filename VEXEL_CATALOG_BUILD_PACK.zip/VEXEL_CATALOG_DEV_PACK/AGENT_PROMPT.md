# AI Agent Prompt — Build Catalog

Goal: Convert raw CSV data into a working Vexel catalog for real lab workflow.

Inputs:
- data/raw/lab_tests.csv
- data/raw/lab_parameters.csv
- your mapping list (test → parameters) if available
- templates/*.csv

Tasks:
1) Normalize raw data (dedupe, clean names, normalize units/specimenType).
2) Produce template CSVs (tests, parameters, test-parameters). Panels optional.
3) Import with validate=true first, then apply.
4) Load reference ranges for pilot parameters (bulk import recommended; otherwise call API per row).
5) Prove end-to-end workflow for 3–5 tests: order → results → verify → render → publish → PDF.

Hard rules:
- contract-first (update OpenAPI + regenerate SDK if you add endpoints)
- tenant-scoped everywhere
- imports idempotent and audited

Deliver:
- OUT/20_CATALOG_BUILD_REPORT.md with counts, errors resolved, and end-to-end proof notes.
