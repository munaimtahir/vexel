# Catalog Build Checklist (MVP → v1)

## 1) Catalog must-have entities
- [ ] Parameters (analytes): name, unit, resultType, optional LOINC/UCUM, active flag
- [ ] Tests (orderables): name, department, specimenType, optional method, price, active flag
- [ ] Test → Parameter mapping: display order, required flag, unit override (rare)
- [ ] Reference ranges: at least adult defaults for pilot parameters
- [ ] Panels (optional): group of tests for “one-click ordering”

## 2) Data prep rules (non-negotiable)
- [ ] `externalId` is stable forever (no spaces, unique)
- [ ] `userCode` is the human code (CBC, LFT, HB) and may be updated later
- [ ] De-duplicate by name + unit + meaning (avoid duplicates like Hb/Hemoglobin)
- [ ] Standardize units (prefer UCUM-like strings)
- [ ] Standardize specimenType strings (avoid EDTA vs Whole Blood mismatch)

## 3) Build import files using templates
- [ ] Fill `parameters-template` (required)
- [ ] Fill `tests-template` (required)
- [ ] Fill `test-parameters-template` (required)
- [ ] Panels templates (optional)

Template headers are in `templates/`.

## 4) Import workflow (safe)
- [ ] Validate import first (no DB changes)
- [ ] Fix validation errors until clean
- [ ] Apply import in `UPSERT_PATCH` mode
- [ ] Re-run same import → no duplicates (idempotent)

## 5) Reference ranges (day-1 requirement)
- [ ] Load adult default ranges for pilot parameters (Hb, WBC, Platelets, Glucose, etc.)
- [ ] Confirm ranges show in results entry and report output

## 6) End-to-end proof (definition of done)
Pick 3–5 tests and prove:
- [ ] Order uses catalog tests
- [ ] Result entry shows correct parameters (order + units)
- [ ] Verify → Render → Publish
- [ ] PDF shows correct units + reference ranges
