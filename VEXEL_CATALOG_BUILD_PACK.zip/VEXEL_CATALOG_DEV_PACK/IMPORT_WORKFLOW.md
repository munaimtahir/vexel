# Import Workflow (Validate → Apply)

Use the existing API workflow:

1) Download workbook template:
- GET `/catalog/templates/workbook.xlsx`

2) Fill the sheets:
- Parameters
- Tests
- TestParameters
- Panels (optional)
- PanelTests (optional)

3) Validate (no DB change):
- POST `/catalog/import` with `validate=true` and `mode=UPSERT_PATCH`

4) Apply:
- POST `/catalog/import` with `validate=false` and `mode=UPSERT_PATCH`

Post-checks:
- list tests, list parameters
- open test definition and confirm ordering
- run a real workflow with 3–5 tests
