# Mapping Raw CSV → Vexel Catalog Templates

Raw inputs you provided:
- `data/raw/lab_tests.csv` columns: id, name, category, price, sampleTypeId
- `data/raw/lab_parameters.csv` columns: id, name, unit, referenceRange

## Tests template (must match)
Headers:
`externalId,userCode,name,department,specimenType,method,loincCode,price,isActive`

Raw mapping:
- id → externalId
- name → name
- category → department
- sampleTypeId → specimenType (normalize)
- price → price
- userCode derived (CBC from parentheses, else acronym)

Starter filled file:
- `data/derived/tests-template-filled.csv`

## Parameters template (must match)
Headers:
`externalId,userCode,name,resultType,defaultUnit,decimals,allowedValues,loincCode,defaultValue,isActive`

Raw mapping:
- id → externalId
- name → name
- unit → defaultUnit
- referenceRange → goes to reference ranges (not parameters template)

Starter filled file:
- `data/derived/parameters-template-filled.csv`

## Test-parameters mapping
Headers:
`testExternalId,parameterExternalId,displayOrder,isRequired,unitOverride`

Your raw data does not include mappings, so this pack includes **suggestions** for the sample data:
- `data/derived/test-parameters-template-suggested.csv`
Review and expand using your full mapping list.

## Reference ranges (recommended)
This pack includes a reference range CSV template:
`templates/reference-ranges-template.csv`

Starter parsed output:
- `data/derived/reference-ranges-template-filled.csv`
