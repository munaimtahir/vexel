# Vexel LIMS — Catalog Build Pack
Date: 2026-02-28

This pack is for the AI agent responsible for **Catalog development** (tests, parameters, mappings, panels, reference ranges, import/export).

You already have raw CSVs (tests + parameters). The agent should convert them into the system's canonical catalog so the LIMS can be used in real lab workflows.

## What is inside
- `CATALOG_CHECKLIST.md` — step-by-step checklist with acceptance criteria.
- `MAPPING_RAW_TO_TEMPLATES.md` — how to map your raw CSV columns to Vexel catalog templates.
- `IMPORT_WORKFLOW.md` — how to use the existing `/catalog/import` pipeline safely (validate → apply).
- `VALIDATION_RULES.md` — strict rules for de-duplication, units, reference ranges, IDs/codes.
- `AGENT_PROMPT.md` — copy/paste mega prompt to execute inside the repo.
- `templates/` — canonical CSV templates (matches API `/catalog/templates/*`).
- `data/raw/` — your raw CSVs (as provided).
- `data/derived/` — prepared filled templates generated from your raw CSVs (starter set).
- `tools/` — helper scripts.

## Minimum target outcome
After this work, a lab operator should be able to:
1) Create a lab order using tests from catalog.
2) Enter results for parameters mapped to those tests.
3) Verify → Render → Publish report and see correct parameter ordering, units, and reference ranges.
