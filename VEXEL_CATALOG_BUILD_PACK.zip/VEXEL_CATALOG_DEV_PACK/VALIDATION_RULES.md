# Validation Rules (Strict)

- externalId must be stable forever; no spaces; unique.
- userCode is the staff-facing code; can be changed later.
- units must be consistent and preferably UCUM-like.
- specimenType must be consistent (avoid EDTA vs Whole Blood mismatch).
- every test must map to at least 1 parameter.
- import must be idempotent (running twice does not duplicate).
