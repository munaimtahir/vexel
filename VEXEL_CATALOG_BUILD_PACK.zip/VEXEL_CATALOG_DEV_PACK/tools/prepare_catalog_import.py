#!/usr/bin/env python3
"""prepare_catalog_import.py
Convert raw lab CSVs to Vexel catalog template CSVs.
"""
import argparse, pandas as pd, re, math, os

SPECIMEN_MAP = {"edta":"Whole Blood (EDTA)","serum":"Serum","plasma":"Plasma","urine":"Urine","csf":"CSF","stool":"Stool","swab":"Swab"}

def acronym_from_name(name:str)->str:
    m=re.search(r"\(([^)]+)\)", str(name))
    if m:
        ac=re.sub(r"[^A-Za-z0-9]+","",m.group(1)).upper()
        if 2 <= len(ac) <= 8:
            return ac
    words=re.findall(r"[A-Za-z0-9]+", str(name))
    ac="".join([w[0] for w in words if w]).upper()
    return ac[:8] if ac else ""

def parse_ref_range(s):
    if s is None or (isinstance(s,float) and math.isnan(s)):
        return (None,None,'unknown')
    t=str(s).strip().replace("–","-").replace("—","-")
    m=re.match(r"^\s*([0-9]*\.?[0-9]+)\s*-\s*([0-9]*\.?[0-9]+)\s*$", t)
    if m:
        return (float(m.group(1)), float(m.group(2)), 'range')
    m=re.match(r"^\s*<\s*([0-9]*\.?[0-9]+)\s*$", t)
    if m:
        return (None, float(m.group(1)), 'lt')
    m=re.match(r"^\s*>\s*([0-9]*\.?[0-9]+)\s*$", t)
    if m:
        return (float(m.group(1)), None, 'gt')
    return (None,None,'unknown')

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--tests', required=True)
    ap.add_argument('--params', required=True)
    ap.add_argument('--out', required=True)
    a=ap.parse_args()

    tests=pd.read_csv(a.tests)
    params=pd.read_csv(a.params)
    os.makedirs(a.out, exist_ok=True)

    # parameters
    pr=[]
    rr=[]
    for _,r in params.iterrows():
        ext=str(r['id']).strip()
        name=str(r['name']).strip()
        unit=str(r.get('unit','')).strip()
        ref=str(r.get('referenceRange','')).strip()
        low, high, typ = parse_ref_range(ref)
        pr.append({'externalId':ext,'userCode':ext.upper(),'name':name,'resultType':'numeric','defaultUnit':unit,'decimals':'','allowedValues':'','loincCode':'','defaultValue':'','isActive':'true'})
        if ref:
            rr.append({'parameterExternalId':ext,'testExternalId':'','gender':'','ageMinYears':'','ageMaxYears':'','lowValue':'' if low is None else str(low),'highValue':'' if high is None else str(high),'criticalLow':'','criticalHigh':'','unit':unit,'notes':'' if typ!='unknown' else f'Unparsed: {ref}'})
    pd.DataFrame(pr).to_csv(os.path.join(a.out,'parameters-template-filled.csv'), index=False)
    pd.DataFrame(rr).to_csv(os.path.join(a.out,'reference-ranges-template-filled.csv'), index=False)

    # tests
    tr=[]
    for _,r in tests.iterrows():
        ext=str(r['id']).strip()
        name=str(r['name']).strip()
        dept=str(r.get('category','')).strip()
        sample=str(r.get('sampleTypeId','')).strip().lower()
        specimen=SPECIMEN_MAP.get(sample, sample)
        price=r.get('price','')
        tr.append({'externalId':ext,'userCode':acronym_from_name(name) or ext.upper(),'name':name,'department':dept,'specimenType':specimen,'method':'','loincCode':'','price':'' if price is None else str(price),'isActive':'true'})
    pd.DataFrame(tr).to_csv(os.path.join(a.out,'tests-template-filled.csv'), index=False)
    print('OK: wrote templates to', a.out)

if __name__=='__main__':
    main()
